# sorts

Demonstrations and visualizations of sorting algorithms.

<img src="images/mergesort.png" title="Merge sort" alt="Merge sort" />
